<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use App\Entity\Employe;
use Doctrine\Persistence\ManagerRegistry;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use App\Form\EmployeType;

class EmployeController extends AbstractController
{
    #[Route('/employe', name: 'app_employe')]
    public function index(): Response
    {
        return $this->render('employe/index.html.twig', [
            'controller_name' => 'EmployeController',
        ]);
    }

    // (p.5, étape 1 & 2), (p.6, étape 8 & 9), (p.7, étape 1 & 2)
    #[Route("/login", "app_employes_connexion")]
    public function seConnecter(ManagerRegistry $doctrine, Request $request, $employe = null, $message = null){
        if($employe == null){
            $employe = new Employe();
        }
        $form = $this->createForm(EmployeType::class, $employe);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $employe = $doctrine->getManager()->getRepository(Employe::class)->verifConnexion($employe->getLogin(), $employe->getMdp());
            if($employe != null){
                if(!isset($session) || !$session->isStarted()){
	                $session = new Session();
                }
                $session->set("e_id", $employe->getId());
                $session->set("e_statut", $employe->getStatut());

                if($session->get("e_statut") == 1){
                    // 1 = employe
                    return $this->redirectToRoute("app_empl_formations_liste");
                } else {
                    // 0 = RH
                    return $this->redirectToRoute("app_rh_menu");
                }
            } else {
                // (p.5, exception 2.a)
                $message = "Identifiants incorrects.";
            }
        }
        return $this->render("seConnecter.twig", ["form" => $form->createView(), "message" => $message]);
    }

    // Mars 2023 - B.3
    #[Route("/accueilGestion", "app_rh_menu")]
    public function accueilGestion(){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        }
        return $this->render("menuGestion.twig", ["message" => $message]);
    }

    // Mars 2023 - B.3
    #[Route("/gererEmployes", "app_rh_employes_liste")]
    public function afficherEmployes(ManagerRegistry $doctrine){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        $lesEmployes = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $statut = 1;
            $lesEmployes = $doctrine->getManager()->getRepository(Employe::class)->findAllByStatus($statut);
            if(!$lesEmployes || $lesEmployes == null){
                $message = "Pas d'employés à afficher.";
            }
        }
        return $this->render("employe/afficherEmployes.twig", ["lesEmployes" => $lesEmployes, "message" => $message]);
    }

    // Bonus
    #[Route("/logout", "app_employes_deconnexion")]
    public function seDeconnecter(){
        $session = new Session();
        if($session->isStarted()){
            $session->clear();
        } //clear(), migrate() ou invalidate()  
        return $this->redirectToRoute("app_employes_connexion");
    }
}
