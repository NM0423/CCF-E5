<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use App\Entity\Formation;
use Doctrine\Persistence\ManagerRegistry;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use App\Form\FormationType;

class FormationController extends AbstractController
{
    #[Route('/formation', name: 'app_formation')]
    public function index(): Response
    {
        return $this->render('formation/index.html.twig', [
            'controller_name' => 'FormationController',
        ]);
    }

    // (p.5, étape 3 & 7)
    #[Route("/gererFormations", "app_rh_formations_liste")]
    public function gererFormations(ManagerRegistry $doctrine, $message = null){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $lesFormations = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $lesFormations = $doctrine->getManager()->getRepository(Formation::class)->findAllAvailable(date("Y-m-d"));
            if(!$lesFormations){
                $message = "Pas de formations disponibles.";
            }
        }
        return $this->render("formation/gererFormations.twig", ["lesFormations" => $lesFormations, "message" => $message]);
    }

    // (p.5, étape 5)
    #[Route("/ajouterFormation", "app_rh_formations_ajouter")]
    public function ajouterFormation(ManagerRegistry $doctrine, Request $request, $formation = null){
        $message = null;
        $form = null;
        if($formation == null){
            $formation = new Formation();
        }
        $form = $this->createForm(FormationType::class, $formation);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $doctrine->getManager()->getRepository(Formation::class)->save($formation, true);
            $message = "La formation a été ajoutée.";
            // (p.5, étape 7)
            return $this->redirectToRoute("app_rh_formations_liste", ["message" => $message]);
        }
        return $this->render("formation/ajouterFormation.twig", ["form" => $form->createView(), "message" => $message]);
    }

    // (p.5, étape 3)
    #[Route("/supprimerFormation={idF}", "app_rh_formations_supprimer")]
    public function supprimerFormation(ManagerRegistry $doctrine, $idF){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        $formation = null;
        $lesInscriptions = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $formation = $doctrine->getManager()->getRepository(Formation::class)->findById($idF);
            $lesInscriptions = $doctrine->getManager()->getRepository(Inscription::class)->findAllByFormationIdId($formation->getId());
            if($formation && $lesInscriptions == null){
                $doctrine->getManager()->getRepository(Formation::class)->remove($formation, true);
                $message = "La formation a bien été supprimée.";
            } else {
                // (p.5, exception 3.b)
                return $this->redirectToRoute("app_rh_formations_erreurSuppr");
            }
        }
        return $this->redirectToRoute("app_rh_formations_liste");
    }
    
    // (p.5, étape 3)
    #[Route("/erreurSuppressionFormation", "app_rh_formations_erreurSuppr")]
    public function erreurSupprFormation(ManagerRegistry $doctrine){
        $message = "Des employés sont inscrits à cette formation. Vous ne pouvez pas la supprimer";
        return $this->render("formation/message_erreurSuppr.twig", ["message" => $message]);
    }

    // (p.6, étape 10)
    #[Route("/afficherFormations", "app_empl_formations_liste")]
    public function afficherFormations(ManagerRegistry $doctrine, $message = null){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $lesFormations = null;
        if($session->get("e_statut") != 1){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $lesFormations = $doctrine->getManager()->getRepository(Formation::class)->findAllAvailable(date("Y-m-d"));
            if(!$lesFormations){
                $message = "Pas de formations disponibles.";
            }
        }
        return $this->render("formation/afficherFormations.twig", array("lesFormations" => $lesFormations, "message" => $message));
    }
}
