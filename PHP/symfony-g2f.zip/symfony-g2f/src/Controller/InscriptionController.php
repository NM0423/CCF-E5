<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use App\Entity\Formation;
use App\Entity\Inscription;
use App\Entity\Employe;
use Doctrine\Persistence\ManagerRegistry;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;

class InscriptionController extends AbstractController
{
    #[Route('/inscription', name: 'app_inscription')]
    public function index(): Response
    {
        return $this->render('inscription/index.html.twig', [
            'controller_name' => 'InscriptionController',
        ]);
    }

    // (p.6, étape 11 & 12)
    #[Route("/inscriptionFormation={idF}", "app_empl_formations_inscription")]
    public function inscriptionFormation(ManagerRegistry $doctrine, $idF){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        $idE = $session->get("e_id");
        if($session->get("e_statut") != 1){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $em = $doctrine->getManager();
            $lesInscriptions = $em->getRepository(Inscription::class)->findByEmployeeIdAndFormationId($idE, $idF);
            // (nov. 2022)
            if(!$lesInscriptions){
                $employe = $em->getRepository(Employe::class)->findOneById($idE);
                $formation = $em->getRepository(Formation::class)->findById($idF);
            
                $inscription = new Inscription();
                $inscription->setLeEmploye($employe);
                $inscription->setLaFormation($formation);
                $inscription->setStatut("En attente");
                $em->getRepository(Inscription::class)->save($inscription, true);

                $insc = $em->getRepository(Inscription::class)->find($inscription->getId());
                if($insc){
                    $message = "Inscription réussie.";
                } else {
                    $message = "Une erreur est survenue : L'inscription a échoué.";
                }
            } else {
                $message = "Une erreur est survenue : Vous êtes déja inscrit à cette formation.";
            }
            return $this->render("inscription/message_resultatDemandeInsc.twig", ["message" => $message]);
        }
    }

    #[Route("/afficherInscriptions", "app_empl_inscriptions_liste")]
    public function afficherInscriptions(ManagerRegistry $doctrine, $message = null){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $lesInscriptions = null;
        $employe = null;
        if($session->get("e_statut") != 1){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $idE = $session->get("e_id");
            $em = $doctrine->getManager();
            $lesInscriptions = $em->getRepository(Inscription::class)->findAllByEmployeeId($idE);
            $employe = $em->getRepository(Employe::class)->findOneById($idE);
            if(!$lesInscriptions){
                $message = "Vous n'êtes inscrit à aucune formation.";
            }
        }
        return $this->render("inscription/afficherInscriptions.twig", ["lesInscriptions" => $lesInscriptions, "message" => $message, "employe" => $employe]);
    }

    // Mars 2023 - B.3
    #[Route("/voirInscriptionsEmploye={idE}", "app_rh_inscriptions_liste")]
    public function voirInscriptions(ManagerRegistry $doctrine, $idE){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        $lesInscriptions = null;
        $employe = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $em = $doctrine->getManager();
            $lesInscriptions = $em->getRepository(Inscription::class)->findAllByEmployeeId($idE);
            $employe = $em->getRepository(Employe::class)->findOneById($idE);
            if(!$lesInscriptions){
                $message = "n'est inscrit à aucune formation.";
            }
        }
        return $this->render("inscription/voirInscriptionsEmploye.twig", ["lesInscriptions" => $lesInscriptions, "employe" => $employe, "message" => $message]);
    }

    // (p.7, étape 3 & 4) gerer rh
    #[Route("/gererInscriptions={idF}", "app_rh_inscriptions_gerer")]
    public function gererInscriptions(ManagerRegistry $doctrine, $idF, $message = null){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $lesInscriptions = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $lesInscriptions = $doctrine->getManager()->getRepository(Inscription::class)->findAllPendingByFormationId($idF);
            $formation = $doctrine->getManager()->getRepository(Formation::class)->findById($idF);
            if(!$lesInscriptions){
                $message = "Pas d'inscriptions en attente.";
            }
        }
        return $this->render("inscription/gererInscriptionsFormation.twig", ["formation" => $formation,"lesInscriptions" => $lesInscriptions, "message" => $message]);
    }

    // (p.7, étape 4 & 5) valider rh
    #[Route("/validerInscription={idI}", "app_rh_inscriptions_valider")]
    public function validerInscription(ManagerRegistry $doctrine, $idI){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        $inscription = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $emi = $doctrine->getManager()->getRepository(Inscription::class);
            $inscription = $emi->find($idI);
            $inscription->setStatut("Validée");
            $emi->save($inscription, true);
            $message = "Le statut de l'inscription n°".$idI." a bien été mis à jour. Nouveau statut : \"Validée\"";
        }
            // le param est dans l'url
            //return $this->redirectToRoute("app_rh_inscriptions_gerer", ["message" => $message]);
        return $this->render("inscription/message_gestionInscriptions.twig", ["message" => $message, "inscription" => $inscription]);
    }

    // (p.7, étape 4 & 5) refuser rh
    #[Route("/refuserInscription={idI}", "app_rh_inscriptions_refuser")]
    public function refuserInscription(ManagerRegistry $doctrine, $idI){
        if(!isset($session) || !$session->isStarted()){
            $session = new Session();
        }
        $message = null;
        $inscription = null;
        if($session->get("e_statut") != 0){
            $message = "Cette ressource ne vous est pas accessible.";
        } else {
            $emi = $doctrine->getManager()->getRepository(Inscription::class);
            $inscription = $emi->find($idI);
            $inscription->setStatut("Refusée");
            $emi->save($inscription, true);
            $message = "Le statut de l'inscription n°".$idI." a bien été mis à jour. Nouveau statut : \"Refusée\"";
        }
            // le param est dans l'url
            //return $this->redirectToRoute("app_rh_inscriptions_gerer", ["message" => $message]);
        return $this->render("inscription/message_gestionInscriptions.twig", ["message" => $message, "inscription" => $inscription]);
    }
}
