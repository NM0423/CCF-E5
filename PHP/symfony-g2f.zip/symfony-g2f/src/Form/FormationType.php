<?php

namespace App\Form;

use App\Entity\Formation;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

use Symfony\Component\Form\Extension\Core\Type as SFType;

class FormationType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('dateDebut', SFType\DateType::class, array("label" => "Date de début de la formation : ", "required" => true))
            ->add('nbHeures', SFType\IntegerType::class, array("label" => "Nombre d'heures de la formation : ", "required" => true))
            ->add('departement', SFType\TextType::class, array("label" => "Service concerné : ", "required" => true))
            ->add('leProduit', EntityType::class, array("label" => "Thème : ", "class" => "App\Entity\Produit", "choice_label" => "libelle"))
            ->add('save', SFType\SubmitType::class, array("label" => "Ajouter"));
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Formation::class,
        ]);
    }
}
