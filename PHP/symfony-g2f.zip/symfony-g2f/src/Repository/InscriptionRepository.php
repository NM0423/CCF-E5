<?php

namespace App\Repository;

use App\Entity\Inscription;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Inscription>
 *
 * @method Inscription|null find($id, $lockMode = null, $lockVersion = null)
 * @method Inscription|null findOneBy(array $criteria, array $orderBy = null)
 * @method Inscription[]    findAll()
 * @method Inscription[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class InscriptionRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Inscription::class);
    }

    public function save(Inscription $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(Inscription $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    // (Route "Inscription/afficherInscriptions" ; "Inscription/voirInscriptionsEmploye")
    public function findAllByEmployeeId($id): array
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.leEmploye = :val')
            ->setParameter('val', $id)
            ->orderBy('i.id', 'ASC')
            ->getQuery()
            ->getResult()
        ;
    }

    // (Route "Formation/supprimerFormation") -> (pas de where statut en attente or validé -> historique / traçabilité refusés)
    public function findAllByFormationId($id): array
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.laFormation = :val')
            ->setParameter('val', $id)
            ->orderBy('i.id', 'ASC')
            ->getQuery()
            ->getResult()
        ;
    }

    // (Route "Inscription/gererInscriptions")
    public function findAllPendingByFormationId($idF): array
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.laFormation >= CURRENT_DATE()')
            ->andWhere("i.statut = 'En attente'")
            ->andWhere("i.laFormation = :idF")
            ->setParameter("idF", $idF)
            ->orderBy('i.id', 'ASC')
            ->getQuery()
            ->getResult()
        ;
    }

    // (Route "Inscription/inscriptionFormation")
    public function findByEmployeeIdAndFormationId($idE, $idF){
        return $this->createQueryBuilder('i')
            ->andWhere('i.leEmploye = :idE')
            ->andWhere("i.statut = 'Validée'")
            ->andWhere("i.laFormation = :idF")
            ->setParameter("idE", $idE)
            ->setParameter("idF", $idF)
            ->orderBy('i.id', 'ASC')
            ->getQuery()
            ->getResult()
        ;
    }

//    /**
//     * @return Inscription[] Returns an array of Inscription objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('i')
//            ->andWhere('i.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('i.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }

//    public function findOneBySomeField($value): ?Inscription
//    {
//        return $this->createQueryBuilder('i')
//            ->andWhere('i.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}
